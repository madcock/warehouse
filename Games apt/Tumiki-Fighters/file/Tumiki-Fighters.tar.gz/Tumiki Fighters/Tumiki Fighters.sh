#!/bin/bash
APPNAME="tumiki-fighters"
PARAMS="-res 320 240"

# Install if necessary.
type $APPNAME >/dev/null 2>&1 || {
    x-terminal-emulator -e "printf '$APPNAME not installed. Installing...\n' && sudo apt-get -y install $APPNAME"
}

# Remap keys
xmodmap -e "keysym j = z"
xmodmap -e "keysym k = x"
xmodmap -e "keysym u = X"
xmodmap -e "keysym i = Z"
xmodmap -e "keysym space = P"

# Run application
$APPNAME $PARAMS

# Restore xmodmap keymappings.
# NOTE: Reboot or run this command manually if keymappings fail to restore due to crash, etc.
setxkbmap

