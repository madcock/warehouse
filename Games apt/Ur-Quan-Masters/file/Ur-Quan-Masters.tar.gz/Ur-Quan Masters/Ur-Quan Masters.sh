#!/bin/bash
APPNAME="uqm"
PARAMS="--res=320x240 --fullscreen"
PKGNAME="uqm uqm-content uqm-music uqm-voice"

# Install if necessary.
type $APPNAME >/dev/null 2>&1 || {
	x-terminal-emulator -e "printf '$PKGNAME not installed. Installing...\n' && sudo sed -i -- '/^deb .*stable main contrib$/ s/$/ non-free/' /etc/apt/sources.list && sudo apt-get -o Acquire::Check-Valid-Until=false -y update && sudo apt-get -o Acquire::Check-Valid-Until=false -y install $PKGNAME"
}

# Remap keys
xmodmap -e "keysym j = Control_R"
xmodmap -e "keysym k = Shift_R"
xmodmap -e "keysym u = Escape"
xmodmap -e "keysym i = F1"
#xmodmap -e "keysym Return = Return"
#xmodmap -e "keysym space = space"
#xmodmap -e "keysym KP_Subtract = KP_Subtract"
#xmodmap -e "keysym KP_Add = KP_Add"
xmodmap -e "keysym Backspace = F10"
xmodmap -e "keysym h = Next"
xmodmap -e "keysym l = End"
xmodmap -e "keysym y = Home"
xmodmap -e "keysym o = Prior"

# Run application
$APPNAME $PARAMS

# Restore xmodmap keymappings.
# NOTE: Reboot or run this command manually if keymappings fail to restore due to crash, etc.
setxkbmap
