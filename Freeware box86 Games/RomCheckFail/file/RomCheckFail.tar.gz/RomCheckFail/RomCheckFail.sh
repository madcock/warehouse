#!/bin/bash
#Remap keys
xmodmap -e "keysym j = space"
xmodmap -e "keysym k = space"
xmodmap -e "keysym u = space"
xmodmap -e "keysym i = space"

#Run application
export LD_LIBRARY_PATH="./lib":"./bin":$LD_LIBRARY_PATH
./box86 bin/RomCheckFail > log.txt

#Restore xmodmap keymappings.
#NOTE: Reboot or run this manually if there is a crash, etc.
setxkbmap
