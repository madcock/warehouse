#!/bin/bash
# Remap keys
xmodmap -e "keysym j = z"
xmodmap -e "keysym k = x"
xmodmap -e "keysym u = X"
xmodmap -e "keysym i = Z"

# Run application
./box86 SuperCrateBoxTogether > log.txt

# Restore xmodmap keymappings.
# NOTE: Reboot or run this command manually if keymappings fail to restore due to crash, etc.
setxkbmap
