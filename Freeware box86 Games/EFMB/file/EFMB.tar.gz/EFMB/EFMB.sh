#!/bin/bash
./box86 runner > log.txt