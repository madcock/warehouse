#!/bin/bash
APPNAME="spout"
PARAMS="-f -z 2"

# Install if necessary.
type $APPNAME >/dev/null 2>&1 || {
	x-terminal-emulator -e "printf '$APPNAME not installed. Installing...\n' && sudo apt-get -y install $APPNAME"
}

# Remap keys
xmodmap -e "keysym j = Return"
xmodmap -e "keysym k = Return"
xmodmap -e "keysym u = Return"
xmodmap -e "keysym i = Return"
xmodmap -e "keysym space = Shift_L"

# Run application
$APPNAME $PARAMS

# Restore xmodmap keymappings.
# NOTE: Reboot or run this command manually if keymappings fail to restore due to crash, etc.
setxkbmap
